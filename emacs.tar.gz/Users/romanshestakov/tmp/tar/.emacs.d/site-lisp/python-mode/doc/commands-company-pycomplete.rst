Python-mode commands

====================

company-pycomplete
------------------
A `company-mode' completion back-end for pycomplete.

