


print(u'\xA9')
