class {
  this_is_bad
}
