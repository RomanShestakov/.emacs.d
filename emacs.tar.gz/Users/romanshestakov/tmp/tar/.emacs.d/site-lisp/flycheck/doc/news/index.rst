===============
 Flycheck news
===============

.. toctree::
   :maxdepth: 1

   flycheck-0.18-released
   flycheck-0.17-released
   flycheck-0.16-released
   flycheck-0.15-released
