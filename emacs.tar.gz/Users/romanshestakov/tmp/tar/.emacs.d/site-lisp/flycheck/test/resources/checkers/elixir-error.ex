# Test an error from Elixir

defmodule AnError do
  def error_func do
    puts "Flycheck is great!"
  end
end
