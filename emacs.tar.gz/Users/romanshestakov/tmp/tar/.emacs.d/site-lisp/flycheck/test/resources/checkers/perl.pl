package perl;

use strict;
use warnings;

$x = <*.pl>;

system('ls');

die if undef;
1;
