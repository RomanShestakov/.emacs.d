// A simple import error in Go test file

package main

import "testing"

func TestFoo(t *testing.T) {
	fmt.Println("foo")
}
