module Haskell.SearchPath where

import Foo.Bar (hello)

helloYou = hello "you"
