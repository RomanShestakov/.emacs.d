=========
 License
=========

.. include:: ../COPYING
   :literal:
