# A syntax error caused by a missing quote
# Taken from http://stackoverflow.com/a/7317453/355252

days = "abc
puts "Here are the days"
