#!/bin/sh
rm "~/my file.txt"
touch $@
