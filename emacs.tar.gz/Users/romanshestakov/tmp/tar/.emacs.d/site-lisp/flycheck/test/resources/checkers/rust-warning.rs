// a warning for an unused variable

fn main() {
    let x = 5;
}
