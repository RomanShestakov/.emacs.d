================================
 GNU Free Documentation License
================================

.. literalinclude:: ../fdl.txt
