class test {};

#include <c_c++-clang-bad-header.h>
