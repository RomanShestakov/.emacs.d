==============
 Introduction
==============

Flycheck is a modern on-the-fly syntax checking extension for GNU Emacs 24.

.. _features:

Features
========

Flycheck is a modern on-the-fly syntax checking extension for GNU Emacs 24.

- Support for |#flycheck-languages| languages with |#flycheck-checkers| syntax
  checkers, see :doc:`languages`
- :ref:`Fully automatic syntax checking in the background <syntax-checking>`
- :ref:`Nice error indication and highlighting <error-reporting>`
- Optional error list popup
- :ref:`Many customization options <syntax-checker-configuration>`
- :doc:`A comprehensive manual <index>`
- :ref:`A dead simple API to create new syntax checkers
  <defining-new-syntax-checkers>`
- A “doesn't get in your way” guarantee

.. _3rd-party-extensions:

3rd party extensions
====================

The following extensions provide additional cool features for Flycheck:

- flycheck-cask_ makes Flycheck use Cask packages in Cask_ projects.
- flycheck-color-mode-line_ colors the mode line according to the Flycheck
  status.
- flycheck-d-unittest_ adds a Flycheck checker to run unit tests for D programs
  on the fly.
- flycheck-google-cpplint_ adds a syntax checker for Google's C++ style checker.
- flycheck-haskell_ improves Haskell support in Flycheck, by configuring
  Flycheck according to the current Cabal project, and using Cabal sandbox
  packages.
- flycheck-hdevtools_ adds a Flycheck syntax checker for Haskell based on
  hdevtools_.
- flycheck-mercury_ adds a Flycheck syntax checker for the `Mercury Language`_.

.. _flycheck-cask: https://github.com/flycheck/flycheck-cask
.. _Cask: https://github.com/cask/cask
.. _flycheck-color-mode-line: https://github.com/flycheck/flycheck-color-mode-line
.. _flycheck-d-unittest: https://github.com/flycheck/flycheck-d-unittest
.. _flycheck-google-cpplint: https://github.com/flycheck/flycheck-google-cpplint
.. _flycheck-haskell: https://github.com/flycheck/flycheck-haskell
.. _flycheck-hdevtools: https://github.com/flycheck/flycheck-hdevtools
.. _hdevtools: https://github.com/bitc/hdevtools/
.. _flycheck-mercury: https://github.com/flycheck/flycheck-mercury
.. _Mercury language: http://mercurylang.org/
